//
//  Ranking.swift
//  basic-testing
//
//  Created by Eliel Gordon on 5/23/18.
//  Copyright © 2018 MakeSchool. All rights reserved.
//

import Foundation

struct Ranking: Decodable {
    let rank: Int
    let domain: String
}
